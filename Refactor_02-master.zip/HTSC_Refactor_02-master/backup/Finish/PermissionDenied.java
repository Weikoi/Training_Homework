package Finish;

public class PermissionDenied extends PermissionState {

	protected PermissionDenied() {
		super("DENIED");
		// TODO Auto-generated constructor stub
	}

}
