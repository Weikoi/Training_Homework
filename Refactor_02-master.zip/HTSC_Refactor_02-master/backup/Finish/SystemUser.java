package Finish;

public class SystemUser {

}
