package Finish;

public class PermissionGranted extends PermissionState {
	
	protected PermissionGranted() {
		super("GRANTED");
		// TODO Auto-generated constructor stub
	}
	
}
